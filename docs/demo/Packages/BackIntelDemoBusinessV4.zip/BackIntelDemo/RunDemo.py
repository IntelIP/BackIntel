import sys
sys.dont_write_bytecode = True
from scripts.package_business_demo import main
main()
