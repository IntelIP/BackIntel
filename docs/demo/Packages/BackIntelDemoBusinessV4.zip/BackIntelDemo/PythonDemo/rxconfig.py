import reflex as rx
config = rx.Config(app_name="reflex_demo", frontend_port=3003, backend_port=3003, api_url="http://127.0.0.1:3003", backend_host="127.0.0.1", show_built_with_reflex=False)
