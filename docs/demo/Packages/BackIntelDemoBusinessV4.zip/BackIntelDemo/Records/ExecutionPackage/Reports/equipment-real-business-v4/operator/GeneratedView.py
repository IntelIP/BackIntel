import json
snapshot = json.load(open("/input/snapshot.json"))
rows = sorted(snapshot["rows"], key=lambda row: row["prediction"] if row["prediction"] is not None else -1, reverse=True)
print(json.dumps({"schema": "backintel-generated-layout/v1", "title": "Predicted outcomes in descending order",
                  "columns": ["entity", "prediction", "target_at", "attention"], "sources": [row["source"] for row in rows]}))
